"use client";

import { TrashIcon } from "@/app/components/icons";

export default function ReferencesPanel({
  references,
  loading,
  activeMarker,
  onSelectReference,
  onMarkerHover,
  onDeleteReference,
  mutatingRefId = null,
}) {
  const canDelete = typeof onDeleteReference === "function";

  return (
    <div className="ref-panel">
      <div className="ref-panel-head">
        <span className="ref-panel-title">REFERENCES</span>
        {canDelete && (
          <span className="ref-panel-hint">Remove entries with the trash icon</span>
        )}
      </div>
      {loading ? (
        <div className="ref-panel-loading">
          <div className="mini-spinner" />
          Finding related papers…
        </div>
      ) : references.length === 0 ? (
        <div className="ref-panel-empty">No references yet</div>
      ) : (
        <ul className="ref-list">
          {references.map((ref) => (
            <li key={ref.id ?? ref.marker}>
              <div className="ref-item-wrap">
                <div className="ref-item-row">
                  <button
                    type="button"
                    id={`ref-${ref.marker}`}
                    className={`ref-item${activeMarker === ref.marker ? " active" : ""}`}
                    disabled={mutatingRefId === ref.id}
                    onClick={() => onSelectReference(ref)}
                    onMouseEnter={() => onMarkerHover?.(ref.marker)}
                    onMouseLeave={() => onMarkerHover?.(null)}
                  >
                    <span className="ref-marker">[{ref.marker}]</span>
                    <span className="ref-body">
                      <span className="ref-title">{ref.title}</span>
                      {(ref.authors || ref.year) && (
                        <span className="ref-meta">
                          {ref.authors}
                          {ref.authors && ref.year ? " · " : ""}
                          {ref.year || ""}
                        </span>
                      )}
                      {ref.kind === "upload" && (
                        <span className="ref-kind">Uploaded file</span>
                      )}
                    </span>
                    {ref.url && (
                      <a
                        className="ref-ext"
                        href={ref.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        title="Open source"
                      >
                        ↗
                      </a>
                    )}
                  </button>
                  {canDelete && (
                    <div className="ref-item-actions">
                      <button
                        type="button"
                        className="ref-trash-btn"
                        title="Remove from list"
                        aria-label={`Remove reference ${ref.marker}`}
                        disabled={mutatingRefId === ref.id}
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          void onDeleteReference(ref);
                        }}
                      >
                        <TrashIcon size={14} />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
