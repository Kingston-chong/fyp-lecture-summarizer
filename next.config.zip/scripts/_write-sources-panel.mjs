import fs from "fs";

const t = "div";

const content = `"use client";

import { DocIco } from "@/app/components/icons";

export default function SourcesListPanel({
  summary,
  extraSources = [],
  onPreview,
  emptyMessage = 'No attached sources. Use "Add sources" to pick documents from the dashboard.',
  listClassName = "src-list",
}) {
  const base = summary?.files || [];
  const extras = extraSources.filter((es) => !base.some((f) => f.id === es.id));
  const all = [...base, ...extras];

  return (
    <${t} className={listClassName}>
      {!all.length ? (
        <${t} className="src-empty">{emptyMessage}</${t}>
      ) : (
        all.map((f) => (
          <${t} key={f.id} className="src-item">
            <DocIco ext={f.type} />
            <${t} className="src-info">
              <${t} className="src-name" title={f.name}>
                {f.name}
              </${t}>
              <${t} className="src-meta">{f.type}</${t}>
            </${t}>
            <button
              type="button"
              className="src-preview-btn"
              onClick={(ev) => onPreview(f, ev)}
              title="Preview file"
              aria-label={\`Preview \${f.name}\`}
            >
              Preview
            </button>
          </${t}>
        ))
      )}
    </${t}>
  );
}
`;

fs.writeFileSync("app/summary/[id]/components/SourcesListPanel.jsx", content);
