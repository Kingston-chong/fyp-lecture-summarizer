import fs from "fs";

const path = "app/summary/[id]/SummaryPageContent.jsx";
let s = fs.readFileSync(path, "utf8");

// Remove duplicate ChatBubbleContent through exportPDF function
const start = s.indexOf("// ─── Stable chat bubble");
const end = s.indexOf("\n\n// Component");
if (start >= 0 && end > start) {
  s = s.slice(0, start) + s.slice(end + 2);
}

// Remove memo from react import if unused
s = s.replace(/,\n  memo,/g, ",");

// exportPDF -> exportSummaryPdf
s = s.replace(/\bexportPDF\b/g, "exportSummaryPdf");

// model param blocks
s = s.replace(
  /const modelParam =\s*chatModel === "DeepSeek"\s*\? "deepseek"\s*: chatModel === "Gemini"\s*\? "gemini"\s*: "chatgpt";/g,
  "const modelParam = mapChatModelToApi(chatModel);",
);

fs.writeFileSync(path, s);
console.log("Cleaned lines:", s.split("\n").length);
