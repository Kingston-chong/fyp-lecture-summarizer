import fs from "fs";

const lines = fs.readFileSync("app/summary/[id]/page.jsx", "utf8").split(/\r?\n/);
const jsx = lines
  .slice(2856, 3189)
  .join("\n")
  .replace(/quizAttemptDetail/g, "detail")
  .replace(/setQuizAttemptDetail\(null\)/g, "onClose()");

const header = `"use client";

import { formatSlideDeckSavedAt } from "../helpers";

export default function QuizAttemptDetailModal({ detail, onClose }) {
  if (!detail) return null;
  const totalQ = detail.totalQuestions || detail.rows.length || 1;
  const score = detail.score ?? 0;
  const pct = Math.round((score / totalQ) * 100);
  const grade =
    pct >= 90
      ? { label: "Excellent", color: "#22c55e", bg: "rgba(34,197,94,0.10)" }
      : pct >= 70
        ? { label: "Good", color: "#3b82f6", bg: "rgba(59,130,246,0.10)" }
        : pct >= 50
          ? { label: "Fair", color: "#f59e0b", bg: "rgba(245,158,11,0.10)" }
          : { label: "Needs work", color: "#ef4444", bg: "rgba(239,68,68,0.10)" };

  return (
`;

const footer = `
  );
}
`;

fs.writeFileSync(
  "app/summary/[id]/components/QuizAttemptDetailModal.jsx",
  header + jsx + footer,
);
console.log("ok", header.length + jsx.length);
