import fs from "fs";
import path from "path";

const root = path.resolve("app/summary/[id]");
const page = fs.readFileSync(path.join(root, "page.jsx"), "utf8");
const lines = page.split(/\r?\n/);

function slice(start, end) {
  return lines.slice(start - 1, end).join("\n");
}

function write(rel, content) {
  const file = path.join(root, rel);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, content.replace(/\r\n/g, "\n"));
  console.log("wrote", rel, content.split("\n").length, "lines");
}

// QuizAttemptDetailModal: inner modal from lines 2856-3189
const quizInner = slice(2857, 3189)
  .replace(/setQuizAttemptDetail\(null\)/g, "onClose()");

write(
  "components/QuizAttemptDetailModal.jsx",
  `"use client";

import { formatSlideDeckSavedAt } from "../helpers";

export default function QuizAttemptDetailModal({ detail, onClose }) {
  if (!detail) return null;
  const totalQ = detail.totalQuestions || detail.rows.length || 1;
  const score = detail.score ?? 0;
  const pct = Math.round((score / totalQ) * 100);
  const grade =
    pct >= 90
      ? { label: "Excellent", color: "#22c55e", bg: "rgba(34,197,94,0.10)" }
      : pct >= 70
        ? { label: "Good", color: "#3b82f6", bg: "rgba(59,130,246,0.10)" }
        : pct >= 50
          ? { label: "Fair", color: "#f59e0b", bg: "rgba(245,158,11,0.10)" }
          : { label: "Needs work", color: "#ef4444", bg: "rgba(239,68,68,0.10)" };

  return (
    <motion
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 1200,
        background: "rgba(4,6,15,0.72)",
        backdropFilter: "blur(8px)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 16,
      }}
    >
${quizInner
  .replace(/quizAttemptDetail/g, "detail")
  .split("\n")
  .map((l) => "      " + l)
  .join("\n")}
    </motion>
  );
}
`.replace(/motion/g, "motion".replace("motion", "div")),
);

console.log("done partial");
