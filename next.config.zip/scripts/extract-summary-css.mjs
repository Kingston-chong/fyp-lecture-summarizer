import fs from "fs";
import path from "path";

const root = path.join(process.cwd(), "app/summary/[id]");
const pagePath = path.join(root, "page.jsx");
const cssPath = path.join(root, "summary-page.css");

let page = fs.readFileSync(pagePath, "utf8");
const start = page.indexOf("<style>{`");
const end = page.indexOf("`}</style>", start);
if (start < 0 || end < 0) {
  console.error("Main style block not found");
  process.exit(1);
}

let css = page.slice(start + "<style>{`".length, end);
css = css.replace(/^\s*\n/, "").trim();

const extra = `
/* Quiz attempt modal */
@keyframes qa-fade-in { from { opacity:0; transform:scale(0.97) translateY(6px); } to { opacity:1; transform:none; } }
.qa-modal { animation: qa-fade-in 0.2s cubic-bezier(.22,.68,0,1.2); }
.qa-row-card { transition: background 0.15s; }
.qa-row-card:hover { background: rgba(255,255,255,0.04) !important; }
.qa-close-btn:hover { background: rgba(255,255,255,0.10) !important; }
.qa-dismiss-btn:hover { opacity: 0.8; }
.qa-scroll::-webkit-scrollbar { width: 4px; }
.qa-scroll::-webkit-scrollbar-track { background: transparent; }
.qa-scroll::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.12); border-radius: 4px; }

/* Mobile more sheet */
@keyframes mob-sheet-up { from { transform: translateY(100%); } to { transform: translateY(0); } }
.mob-more-overlay { position:fixed; inset:0; z-index:1300; background:rgba(4,6,15,0.65); backdrop-filter:blur(6px); display:flex; flex-direction:column; justify-content:flex-end; }
.mob-more-sheet { background:var(--sum-card-bg); border:1px solid var(--sum-card-border); border-bottom:none; border-radius:18px 18px 0 0; max-height:88vh; display:flex; flex-direction:column; animation:mob-sheet-up 0.28s cubic-bezier(.22,.68,0,1.2); box-shadow:0 -16px 48px rgba(0,0,0,0.45); }
.mob-more-handle { width:36px; height:4px; border-radius:2px; background:rgba(255,255,255,0.18); margin:10px auto 0; flex-shrink:0; }
.mob-more-header { display:flex; align-items:center; justify-content:space-between; padding:12px 16px 10px; border-bottom:1px solid var(--sum-head-border); flex-shrink:0; }
.mob-more-title { font-size:13px; font-weight:700; opacity:0.55; letter-spacing:0.07em; text-transform:uppercase; }
.mob-more-close { width:30px; height:30px; border-radius:8px; border:1px solid var(--sum-card-border); background:transparent; color:inherit; cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:17px; }
.mob-more-body { overflow-y:auto; flex:1; min-height:0; padding:12px; display:flex; flex-direction:column; gap:10px; }
.mob-more-body::-webkit-scrollbar { width:3px; }
.mob-more-body::-webkit-scrollbar-thumb { background:rgba(255,255,255,0.12); border-radius:3px; }
`;

fs.writeFileSync(cssPath, css + extra);

page = page.replace(/\s*<style>\{`[\s\S]*?`\}<\/style>\n?/g, (m, offset) => {
  if (offset === start) return "\n";
  return "";
});

if (!page.includes('summary-page.css')) {
  page = page.replace('"use client";', '"use client";\n\nimport "./summary-page.css";');
}

fs.writeFileSync(pagePath, page);
console.log("Done. page lines:", page.split("\n").length);
