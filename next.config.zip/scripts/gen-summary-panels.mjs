import fs from "fs";

const lines = fs.readFileSync("app/summary/[id]/page.jsx", "utf8").split(/\r?\n/);
const slice = (a, b) => lines.slice(a - 1, b).join("\n");

const slideDecksBody = slice(2467, 2530);
fs.writeFileSync(
  "app/summary/[id]/components/SlideDecksPanel.jsx",
  `"use client";

import { Spinner } from "@/app/components/icons";
import { formatSlideDeckSavedAt } from "../helpers";

export default function SlideDecksPanel({
  slideDecks,
  slideDecksLoading,
  slideDeckDeletingId,
  onRefresh,
  onPreview,
  onDownload,
  onDelete,
  panelClassName = "hl-panel sd-panel sd-panel--sources",
}) {
  return (
${slideDecksBody
  .replace("void fetchSlideDecks()", "onRefresh()")
  .replace(/fetchSlideDecks/g, "onRefresh")
  .replace(/openSlideDeckPreview\(d\)/g, "onPreview(d)")
  .replace(/downloadSlideDeck\(d\)/g, "onDownload(d)")
  .replace(/deleteSlideDeck\(d\)/g, "onDelete(d)")
  .split("\n")
  .map((l) => "    " + l)
  .join("\n")}
  );
}
`,
);

const savedQuizzesBody = slice(2532, 2670);
fs.writeFileSync(
  "app/summary/[id]/components/SavedQuizzesPanel.jsx",
  `"use client";

import { Fragment } from "react";
import { Spinner } from "@/app/components/icons";
import { formatSlideDeckSavedAt } from "../helpers";

export default function SavedQuizzesPanel({
  quizSets,
  quizSetsLoading,
  quizSetOpeningId,
  quizHistoryOpenId,
  quizHistoryLoading,
  quizHistoryList,
  onRefresh,
  onToggleHistory,
  onOpenSet,
  onOpenAttemptDetail,
  historyHelpText,
  panelClassName = "hl-panel sd-panel sd-panel--sources",
}) {
  return (
${savedQuizzesBody
  .replace("void fetchQuizSets()", "onRefresh()")
  .replace(/fetchQuizSets/g, "onRefresh")
  .replace(/toggleQuizHistoryPanel\(q\.id\)/g, "onToggleHistory(q.id)")
  .replace(/openSavedQuizSet\(q\.id\)/g, "onOpenSet(q.id)")
  .replace(/openQuizAttemptDetail\(a\)/g, "onOpenAttemptDetail(a)")
  .split("\n")
  .map((l) => "    " + l)
  .join("\n")}
  );
}
`,
);

const highlightsBody = slice(2672, 2779);
fs.writeFileSync(
  "app/summary/[id]/components/HighlightsPanel.jsx",
  `"use client";

import { Spinner, SaveIco } from "@/app/components/icons";
import { DEFAULT_HL_HEX } from "../helpers";

export default function HighlightsPanel({
  highlights,
  pendingHighlights,
  hlLoading,
  hlSaving,
  onSave,
  onRemovePending,
  onDelete,
  onHighlightClick,
  panelClassName = "hl-panel hl-panel--sources",
}) {
  const handleClick = (id) => {
    onHighlightClick?.(id);
  };

  return (
${highlightsBody
  .replace(/void flushPendingHighlights\(\)/g, "onSave()")
  .replace(/flushPendingHighlights/g, "onSave")
  .replace(/removePendingHighlight\(p\.clientId\)/g, "onRemovePending(p.clientId)")
  .replace(/deleteHighlight\(h\.id\)/g, "onDelete(h.id)")
  .replace(/onClick=\{\(\) => scrollToHighlight\(p\.clientId\)\}/g, "onClick={() => handleClick(p.clientId)}")
  .replace(/onClick=\{\(\) => scrollToHighlight\(h\.id\)\}/g, "onClick={() => handleClick(h.id)}")
  .split("\n")
  .map((l) => "    " + l)
  .join("\n")}
  );
}
`,
);

console.log("panels ok");
