import fs from "fs";
import path from "path";

const idDir = "app/summary/[id]";
const pagePath = path.join(idDir, "page.jsx");
const page = fs.readFileSync(pagePath, "utf8");

function extractComponent(name, startMarker, endMarker) {
  const start = page.indexOf(startMarker);
  const end = page.indexOf(endMarker, start);
  if (start < 0 || end < 0) throw new Error(`Markers not found for ${name}`);
  return page.slice(start, end);
}

// QuizAttemptDetailModal
const qaStart = "{quizAttemptDetail &&";
const qaEnd = "})()}\n\n      {/* ── Mobile";
const qaBlock = page.slice(page.indexOf(qaStart), page.indexOf(qaEnd));

const qaComponent = `"use client";

import { formatSlideDeckSavedAt } from "../helpers";

export default function QuizAttemptDetailModal({ detail, onClose }) {
  if (!detail) return null;
  const totalQ = detail.totalQuestions || detail.rows.length || 1;
  const score = detail.score ?? 0;
  const pct = Math.round((score / totalQ) * 100);
  const grade =
    pct >= 90
      ? { label: "Excellent", color: "#22c55e", bg: "rgba(34,197,94,0.10)" }
      : pct >= 70
        ? { label: "Good", color: "#3b82f6", bg: "rgba(59,130,246,0.10)" }
        : pct >= 50
          ? { label: "Fair", color: "#f59e0b", bg: "rgba(245,158,11,0.10)" }
          : { label: "Needs work", color: "#ef4444", bg: "rgba(239,68,68,0.10)" };

  return (
${qaBlock
  .replace("{quizAttemptDetail &&\n        (() => {", "")
  .replace(/quizAttemptDetail/g, "detail")
  .replace(/setQuizAttemptDetail\(null\)/g, "onClose()")
  .replace(/^\s*const totalQ[\s\S]*?return \(/m, "(")
  .replace(/\}\)\(\)\s*$/, ")")}
  );
}
`;

fs.writeFileSync(path.join(idDir, "components/QuizAttemptDetailModal.jsx"), qaComponent);
console.log("Wrote QuizAttemptDetailModal.jsx");
