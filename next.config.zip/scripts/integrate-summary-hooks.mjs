import fs from "fs";

const path = "app/summary/[id]/SummaryPageContent.jsx";
let s = fs.readFileSync(path, "utf8");

// Insert hooks after quiz settings state
const marker = "  const [quizSettings, setQuizSettings] = useState(null);";
const hookBlock = `  const [quizSettings, setQuizSettings] = useState(null);

  const {
    sourcesWidth,
    onSplitterMouseDown,
  } = useSourcesPanelResize();

  const slideDecksApi = useSlideDecks({ summaryId, status });
  const {
    slideDecks,
    slideDecksLoading,
    slideDeckDeletingId,
    slideDeckPreviewOpen,
    setSlideDeckPreviewOpen,
    slideDeckPreviewUrl,
    slideDeckRemotePptUrl,
    slideDeckPreviewTitle,
    slideDeckDlRef,
    fetchSlideDecks,
    openSlideDeckPreview,
    downloadSlideDeck,
    deleteSlideDeck,
  } = slideDecksApi;

  const quizSetsApi = useQuizSets({
    summaryId,
    status,
    setQuizData,
    setQuizSettings,
    setQuizView,
  });
  const {
    quizSets,
    quizSetsLoading,
    quizSetOpeningId,
    quizHistoryOpenId,
    quizHistoryLoading,
    quizHistoryList,
    quizAttemptDetail,
    setQuizAttemptDetail,
    fetchQuizSets,
    toggleQuizHistoryPanel,
    openQuizAttemptDetail,
    openSavedQuizSet,
  } = quizSetsApi;`;

if (!s.includes("useSourcesPanelResize()")) {
  s = s.replace(marker, hookBlock);
}

// Remove old slide/quiz state block
s = s.replace(
  /  const \[slideDecks, setSlideDecks\][\s\S]*?const splitterRef = useRef\(null\); \/\/ \{ startX, startWidth \}\n/,
  "",
);

// Remove duplicate sources width state if still there
s = s.replace(
  /  \/\/ Sources sidebar width \+ splitter \(desktop\)\n  const \[sourcesWidth, setSourcesWidth\][\s\S]*?const splitterRef = useRef\(null\); \/\/ \{ startX, startWidth \}\n/,
  "",
);

// Remove fetchSlideDecks through deleteSlideDeck block
const fnStart = s.indexOf("  const fetchSlideDecks = useCallback");
const fnEnd = s.indexOf("  return (", fnStart);
if (fnStart >= 0 && fnEnd > fnStart) {
  s = s.slice(0, fnStart) + s.slice(fnEnd);
}

// Replace quiz attempt modal
s = s.replace(
  /\{quizAttemptDetail &&[\s\S]*?\}\)\(\)\}/,
  `<QuizAttemptDetailModal
        detail={quizAttemptDetail}
        onClose={() => setQuizAttemptDetail(null)}
      />`,
);

// Replace chat selection popover
s = s.replace(
  /\{chatSelectionDraft\?\.text && \([\s\S]*?\)\}/,
  `<ChatSelectionPopover
        draft={chatSelectionDraft}
        onReply={addDraftChatReference}
      />`,
);

// Replace mobile more sheet - find block
const mobStart = s.indexOf("{/* ── Mobile \"More\" bottom sheet ── */}");
const mobEnd = s.indexOf("{/* Chat selection reply popover", mobStart);
if (mobStart >= 0 && mobEnd > mobStart) {
  const mobileReplacement = `{/* ── Mobile "More" bottom sheet ── */}
      <MobileMoreSheet
        open={mobileMoreOpen}
        onClose={() => setMobileMoreOpen(false)}
        summary={summary}
        extraSources={extraSources}
        onSourcePreview={openSourceDocPreview}
        slideDecksProps={{
          slideDecks,
          slideDecksLoading,
          slideDeckDeletingId,
          onRefresh: () => void fetchSlideDecks(),
          onPreview: openSlideDeckPreview,
          onDownload: downloadSlideDeck,
          onDelete: deleteSlideDeck,
        }}
        quizSetsProps={{
          quizSets,
          quizSetsLoading,
          quizSetOpeningId,
          quizHistoryOpenId,
          quizHistoryLoading,
          quizHistoryList,
          onRefresh: () => void fetchQuizSets(),
          onToggleHistory: toggleQuizHistoryPanel,
          onOpenSet: openSavedQuizSet,
          onOpenAttempt: openQuizAttemptDetail,
        }}
        highlightsProps={{
          highlights,
          pendingHighlights,
          hlLoading,
          hlSaving,
          onSave: () => void flushPendingHighlights(),
          onRemovePending: removePendingHighlight,
          onDelete: deleteHighlight,
          onScrollTo: scrollToHighlight,
        }}
      />

      `;
  s = s.slice(0, mobStart) + mobileReplacement + s.slice(mobEnd);
}

// Replace sources sidebar - from splitter to </aside>
let asideStart = s.indexOf('className="sum-splitter"');
const asideEnd = s.indexOf("</aside>", asideStart);
if (asideStart >= 0 && asideEnd > asideStart) {
  const sidebarReplacement = `<SourcesSidebar
              sourcesWidth={sourcesWidth}
              onSplitterMouseDown={onSplitterMouseDown}
              summary={summary}
              extraSources={extraSources}
              onSourcePreview={openSourceDocPreview}
              slideDecksProps={{
                slideDecks,
                slideDecksLoading,
                slideDeckDeletingId,
                onRefresh: () => void fetchSlideDecks(),
                onPreview: openSlideDeckPreview,
                onDownload: downloadSlideDeck,
                onDelete: deleteSlideDeck,
              }}
              quizSetsProps={{
                quizSets,
                quizSetsLoading,
                quizSetOpeningId,
                quizHistoryOpenId,
                quizHistoryLoading,
                quizHistoryList,
                onRefresh: () => void fetchQuizSets(),
                onToggleHistory: toggleQuizHistoryPanel,
                onOpenSet: openSavedQuizSet,
                onOpenAttempt: openQuizAttemptDetail,
              }}
              highlightsProps={{
                highlights,
                pendingHighlights,
                hlLoading,
                hlSaving,
                onSave: () => void flushPendingHighlights(),
                onRemovePending: removePendingHighlight,
                onDelete: deleteHighlight,
                onScrollTo: scrollToHighlight,
              }}
            />`;
  s = s.slice(0, asideStart) + sidebarReplacement + s.slice(asideEnd + "</aside>".length);
}

// Remove splitter drag effect (now in hook)
s = s.replace(
  /  \/\/ Drag-to-resize sources sidebar \(desktop\)\n  useEffect\(\(\) => \{[\s\S]*?\}, \[\]\);\n\n/,
  "",
);

fs.writeFileSync(path, s);
console.log("Integrated hooks, lines:", s.split("\n").length);
