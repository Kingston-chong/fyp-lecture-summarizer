import fs from "fs";

const path = "app/summary/[id]/SummaryPageContent.jsx";
let s = fs.readFileSync(path, "utf8");

// Rename default export
s = s.replace(
  "export default function SummaryView()",
  "export default function SummaryPageContent()",
);

// Add imports after use client
const extraImports = `
import ChatBubbleContent from "./components/ChatBubbleContent";
import ChatSelectionPopover from "./components/ChatSelectionPopover";
import QuizAttemptDetailModal from "./components/QuizAttemptDetailModal";
import SourcesSidebar from "./components/SourcesSidebar";
import MobileMoreSheet from "./components/MobileMoreSheet";
import { useSourcesPanelResize } from "./hooks/useSourcesPanelResize";
import { useSlideDecks } from "./hooks/useSlideDecks";
import { useQuizSets } from "./hooks/useQuizSets";
import {
  MODELS,
  ATTACH_ACCEPT,
  SUMMARY_BODY_INNER_STYLE,
} from "./constants";
import { downscaleImageFileToJpegDataUrl, MAX_CHAT_PASTE_IMAGES } from "./lib/chatImages";
import { chatMessageToApiPayload, mapChatModelToApi } from "./lib/chatApi";
import { exportSummaryPdf } from "./lib/exportSummaryPdf";
import { unwrapHighlightMarks, wrapQuoteInRoot } from "./hooks/highlightDom";
`;

if (!s.includes("SummaryPageContent")) {
  s = s.replace('"use client";', `"use client";${extraImports}`);
}

// Remove old top section through exportPDF
const compIdx = s.indexOf("// Component");
if (compIdx > 0) {
  const useClientEnd = s.indexOf('"use client";') + '"use client";'.length;
  const before = s.slice(0, useClientEnd);
  const after = s.slice(compIdx);
  // keep imports block from original - merge carefully
  const importBlock = s.slice(useClientEnd, s.indexOf("// ─── Stable chat"));
  const mergedImports = `"use client";${extraImports}
import {
  Fragment,
  useState,
  useRef,
  useEffect,
  useLayoutEffect,
  useMemo,
  useCallback,
} from "react";
import { useSession } from "next-auth/react";
import { useRouter, useParams, useSearchParams } from "next/navigation";
import { markdownToHtml } from "@/lib/markdown";
import { buildChatSuggestions } from "@/lib/chatSuggestionsFromSummary";
import Button from "@/app/components/ui/Button";
import DocumentPreviewModal from "@/app/dashboard/components/DocumentPreviewModal";
import { formatBytes, isOfficePreviewName } from "@/app/dashboard/helpers";
import SummaryModalStack from "./components/SummaryModalStack";
import {
  DEFAULT_HL_HEX,
  fmtDate,
  formatSlideDeckSavedAt,
  formatSummaryModelLabel,
  HIGHLIGHT_PRESETS,
  parseNumericSummaryId,
  settingsFromQuizSet,
} from "./helpers";
import {
  Chevron,
  Spinner,
  SendIco,
  CopyIco,
  RegenIco,
  HighlightIco,
  SaveIco,
  BotIco,
  UserIco,
  DocIco,
  QuizIco,
  PdfIco,
  SlidesIco,
  ClipIco,
} from "@/app/components/icons";

`;
  s = mergedImports + after.replace("// Component\n", "");
}

// highlight import path
s = s.replace(
  /from "\.\/hooks\/useSummaryHighlights"/g,
  'from "./hooks/highlightDom"',
);

// exportPDF -> exportSummaryPdf
s = s.replace(/exportPDF\(/g, "exportSummaryPdf(");

// Remove ChatBubbleContent block
s = s.replace(
  /\/\/ ─── Stable chat bubble[\s\S]*?^}\);\n\n\/\/ ─── Helpers[\s\S]*?^}\n\n\/\/ ─── PDF export[\s\S]*?^}\n\n/m,
  "",
);

// Remove duplicate constants block if still present
s = s.replace(
  /const MODELS = \["ChatGPT"[\s\S]*?const SUMMARY_BODY_INNER_STYLE[\s\S]*?;\n\n/g,
  "",
);
s = s.replace(
  /function downscaleImageFileToJpegDataUrl[\s\S]*?^}\n\n/g,
  "",
);
s = s.replace(
  /function chatMessageToApiPayload[\s\S]*?^}\n\n/g,
  "",
);

fs.writeFileSync(path, s);
console.log("Patched", path, "lines:", s.split("\n").length);
