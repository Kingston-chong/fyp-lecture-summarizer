import fs from "fs";

const pagePath = "app/summary/[id]/page.jsx";
let s = fs.readFileSync(pagePath, "utf8");
const start = s.indexOf("function exportPDF");
const end = s.indexOf("\n\n// Component", start);
let fn = s.slice(start, end);
fn = fn.replace("function exportPDF", "export function exportSummaryPdf");
const header = `import { markdownToHtml } from "@/lib/markdown";
import { fmtDate, formatSummaryModelLabel } from "../helpers";

`;
fs.writeFileSync("app/summary/[id]/lib/exportSummaryPdf.js", header + fn);
