import fs from "fs";

const lines = fs.readFileSync("app/summary/[id]/page.jsx", "utf8").split(/\r?\n/);
const state = lines.slice(254, 337).join("\n");
const mid = lines.slice(387, 1225).join("\n");
const sugg = lines.slice(1423, 1478).join("\n");

const content = `import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { buildChatSuggestions } from "@/lib/chatSuggestionsFromSummary";
import { chatMessageToApiPayload } from "../lib/chatApi";
import { downscaleImageFileToJpegDataUrl, MAX_CHAT_PASTE_IMAGES } from "../lib/chatImages";
import { exportSummaryPdf } from "../lib/exportSummaryPdf";
import { MODELS } from "../constants";

export function useSummaryChat({ status, summaryId, summary, headings, summaryBodyRef }) {
${state}
${mid}
${sugg}
  const chatSuggestions = useMemo(() => {
    if (aiChatSuggestions.length > 0) return aiChatSuggestions;
    return buildChatSuggestions({
      markdown: summary?.output || "",
      headings,
      title: summary?.title || "",
      max: 4,
    });
  }, [aiChatSuggestions, summary?.output, summary?.title, headings]);

  return {
    messages,
    inputVal,
    setInputVal,
    chatModel,
    setChatModel,
    modelOpen,
    setModelOpen,
    chatLoading,
    chatNotice,
    pdfLoading,
    aiChatSuggestions,
    sourceUploadLoading,
    extraSources,
    setExtraSources,
    pendingSourceFiles,
    pendingPasteImages,
    chatSelectionDraft,
    pendingChatReferences,
    copiedId,
    bottomRef,
    inputRef,
    sourceInputRef,
    queueChatReference,
    removePendingChatReference,
    addDraftChatReference,
    openReplyPopoverFromSelection,
    handleChatBubbleMouseUp,
    handleCopyMessage,
    sendMessage,
    regenerateLastResponse,
    handlePDF,
    handleAttachmentFilesSelected,
    removePendingPasteByClientId,
    removePendingSourceByClientId,
    chatSuggestions,
    MODELS,
  };
}
`;

fs.writeFileSync("app/summary/[id]/hooks/useSummaryChat.js", content);
console.log("wrote useSummaryChat", content.split("\n").length);
